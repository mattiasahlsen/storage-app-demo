
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'mattiasahlsen',
  applicationName: 'my-first-app',
  appUid: '7pTVswS6JXtgv4f8ng',
  orgUid: 'd2kCGWBF73hscGvRJB',
  deploymentUid: '94a92d4d-aee9-4bac-9892-e3101270020f',
  serviceName: 'my-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.13',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'my-api-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.query, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}